These sample projects provide a quick demo of how to use various functions

Running these assume that you have first compiled libxbee.dll successfully
You will also need to either copy libxbee.dll into this folder or into a
  directory in your PATH

If you want to use libxbee in your own projects, you must include libxbee.bas
  which will provide you with access to the functions and type declarations
